#!/bin/sh

pipenv run python3 bot.py